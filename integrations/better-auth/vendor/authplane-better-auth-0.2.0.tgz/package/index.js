// packages/protocol/src/index.ts
import { z as z5 } from "zod";

// packages/protocol/src/adapter.ts
import { z } from "zod";
var remoteId = z.string().min(1).max(200);
var date = z.iso.datetime();
var userSchema = z.object({
  id: remoteId,
  name: z.string().max(500),
  email: z.string().max(320),
  emailVerified: z.boolean(),
  image: z.string().max(2048).nullable(),
  createdAt: date,
  updatedAt: date,
  role: z.string().max(200).nullable(),
  banned: z.boolean(),
  banReason: z.string().max(1e3).nullable(),
  banExpires: date.nullable(),
  truncatedFields: z.array(z.enum(["name", "email", "image", "role", "banReason"])).max(5).optional()
});
var sessionSchema = z.object({
  id: remoteId,
  userId: remoteId,
  createdAt: date,
  updatedAt: date,
  expiresAt: date,
  ipAddress: z.string().max(200).nullable(),
  userAgent: z.string().max(1024).nullable(),
  truncatedFields: z.array(z.enum(["ipAddress", "userAgent"])).max(2).optional()
});
var listInput = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(25),
  offset: z.coerce.number().int().min(0).max(1e6).default(0)
});
var usersListInput = listInput.extend({ search: z.string().trim().max(200).optional() }).strict();
var sessionsListInput = listInput.extend({ userId: remoteId.optional() }).strict();
var userCreateInput = z.object({
  name: z.string().trim().min(1).max(200),
  email: z.email().max(320),
  password: z.string().min(8).max(128).optional()
}).strict();
var userUpdateInput = z.object({
  name: z.string().trim().min(1).max(200).optional(),
  email: z.email().max(320).optional(),
  image: z.url().max(2048).nullable().optional()
}).strict().refine((v) => Object.keys(v).length > 0, "Provide a profile field");
var userPageSchema = z.object({
  items: z.array(userSchema).max(100),
  total: z.number().int().min(0),
  limit: z.number().int(),
  offset: z.number().int()
});
var sessionPageSchema = z.object({
  items: z.array(sessionSchema).max(100),
  total: z.number().int().min(0),
  limit: z.number().int(),
  offset: z.number().int()
});
var eventDeliveryStateSchema = z.object({
  queued: z.number().int().min(0),
  dropped: z.number().int().min(0),
  failed: z.number().int().min(0),
  lastError: z.enum([
    "outbox_full",
    "event_persistence_failed",
    "event_storage_unavailable",
    "event_delivery_failed",
    "partial_acknowledgement"
  ]).nullable(),
  lastSuccessAt: z.iso.datetime().nullable()
});

// packages/protocol/src/authentication.ts
import { z as z2 } from "zod";
var authenticationMethodsSchema = z2.object({
  emailPassword: z2.object({ enabled: z2.boolean(), resetEmail: z2.boolean() }),
  google: z2.object({
    enabled: z2.boolean(),
    credentialsConfigured: z2.boolean(),
    callbackURL: z2.url().max(2048),
    diagnostics: z2.array(z2.string().max(500)).max(10)
  }),
  twoFactor: z2.object({
    enabled: z2.boolean(),
    totp: z2.boolean(),
    otp: z2.boolean(),
    allowPasswordless: z2.boolean(),
    defaultChallengeMethods: z2.array(z2.enum(["email", "username", "phone-number"])).max(3),
    customEnforcement: z2.literal("application-owned"),
    reset: z2.boolean()
  }),
  magicLink: z2.object({
    enabled: z2.boolean(),
    deliveryConfigured: z2.boolean(),
    expiresIn: z2.number().int().positive(),
    send: z2.boolean()
  }),
  passkeys: z2.object({
    enabled: z2.boolean(),
    rpID: z2.string().max(253),
    origins: z2.array(z2.string().max(2048)).max(20),
    revoke: z2.boolean()
  })
});
var userSecuritySchema = z2.object({
  userId: remoteId,
  emailVerified: z2.boolean(),
  password: z2.boolean(),
  accounts: z2.array(
    z2.object({
      id: remoteId,
      providerId: z2.string().max(200),
      createdAt: z2.iso.datetime()
    })
  ).max(100),
  twoFactor: z2.object({ enabled: z2.boolean(), totpEnrolled: z2.boolean() }),
  passkeys: z2.array(
    z2.object({
      id: remoteId,
      name: z2.string().max(200),
      createdAt: z2.iso.datetime(),
      deviceType: z2.string().max(100),
      backedUp: z2.boolean()
    })
  ).max(100)
});
var recoveryReason = z2.string().trim().min(8).max(300);
var securityOperationInputs = {
  "security.methods": z2.object({}).strict(),
  "security.user": z2.object({ id: remoteId }).strict(),
  "security.sendPasswordReset": z2.object({ id: remoteId, reason: recoveryReason }).strict(),
  "security.sendMagicLink": z2.object({ id: remoteId, reason: recoveryReason }).strict(),
  "security.resetTwoFactor": z2.object({ id: remoteId, reason: recoveryReason }).strict(),
  "security.revokePasskey": z2.object({ id: remoteId, passkeyId: remoteId, reason: recoveryReason }).strict()
};
var success = z2.object({ success: z2.literal(true) });

// packages/protocol/src/events.ts
import { z as z3 } from "zod";
var eventMetadataSchema = z3.object({
  endpoint: z3.string().max(200).optional(),
  management: z3.boolean().optional(),
  method: z3.string().max(50).optional(),
  sessionId: remoteId.optional(),
  teamId: remoteId.optional(),
  memberId: remoteId.optional(),
  invitationId: remoteId.optional()
}).strict();
var sourceEventSchema = z3.object({
  id: z3.uuid(),
  providerEventType: z3.string().min(1).max(100).regex(/^[a-z][a-z0-9_]*$/),
  actorUserId: remoteId.optional(),
  targetUserId: remoteId.optional(),
  organizationId: remoteId.optional(),
  occurredAt: z3.iso.datetime(),
  ip: z3.union([z3.ipv4(), z3.ipv6()]).optional(),
  userAgent: z3.string().max(1024).optional(),
  metadata: eventMetadataSchema
}).strict();
var eventBatchSchema = z3.object({ events: z3.array(sourceEventSchema).min(1).max(100) }).strict();
var eventAckSchema = z3.object({ acceptedIds: z3.array(z3.uuid()).max(100) }).strict();

// packages/protocol/src/organizations.ts
import { z as z4 } from "zod";
var truncatedFields = z4.array(z4.enum(["name", "slug", "logo", "email", "role", "status"])).max(6).optional();
var orgSchema = z4.object({
  id: remoteId,
  name: z4.string().max(500),
  slug: z4.string().max(500),
  logo: z4.string().max(2048).nullable(),
  truncatedFields,
  createdAt: z4.iso.datetime()
});
var memberSchema = z4.object({
  truncatedFields,
  id: remoteId,
  organizationId: remoteId,
  userId: remoteId,
  role: z4.string().max(200),
  createdAt: z4.iso.datetime(),
  name: z4.string().max(500),
  email: z4.string().max(320)
});
var teamSchema = z4.object({
  truncatedFields,
  id: remoteId,
  organizationId: remoteId,
  name: z4.string().max(500),
  createdAt: z4.iso.datetime(),
  updatedAt: z4.iso.datetime().nullable()
});
var teamMemberSchema = z4.object({
  truncatedFields,
  id: remoteId,
  teamId: remoteId,
  userId: remoteId,
  createdAt: z4.iso.datetime(),
  name: z4.string().max(500),
  email: z4.string().max(320)
});
var invitationSchema = z4.object({
  truncatedFields,
  id: remoteId,
  organizationId: remoteId,
  email: z4.string().max(320),
  role: z4.string().max(200).nullable(),
  status: z4.string().max(100),
  expiresAt: z4.iso.datetime(),
  inviterId: remoteId,
  teamId: remoteId.nullable()
});
var orgListInput = listInput.extend({ search: z4.string().trim().max(200).optional() }).strict();
var orgCreateInput = z4.object({
  actorUserId: remoteId,
  name: z4.string().trim().min(1).max(200),
  slug: z4.string().min(1).max(100).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
}).strict();
var orgUpdateInput = z4.object({
  name: z4.string().trim().min(1).max(200).optional(),
  slug: z4.string().min(1).max(100).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).optional(),
  logo: z4.url().max(2048).nullable().optional()
}).strict().refine((v) => Object.keys(v).length > 0);
var orgWrite = z4.object({ organizationId: remoteId, actorUserId: remoteId });
var roleInput = z4.string().min(1).max(100).regex(/^[A-Za-z0-9_-]+$/);
var orgOperationInputs = {
  "organizations.list": orgListInput,
  "organizations.get": z4.object({ organizationId: remoteId }).strict(),
  "organizations.create": orgCreateInput,
  "organizations.update": orgWrite.extend({ data: orgUpdateInput }).strict(),
  "organizations.delete": orgWrite.strict(),
  "members.list": listInput.extend({ organizationId: remoteId }).strict(),
  "members.add": orgWrite.extend({ userId: remoteId, role: roleInput }).strict(),
  "members.role": orgWrite.extend({ memberId: remoteId, role: roleInput }).strict(),
  "members.remove": orgWrite.extend({ memberId: remoteId }).strict(),
  "teams.list": listInput.extend({ organizationId: remoteId }).strict(),
  "teams.create": orgWrite.extend({ name: z4.string().trim().min(1).max(200) }).strict(),
  "teams.update": orgWrite.extend({ teamId: remoteId, name: z4.string().trim().min(1).max(200) }).strict(),
  "teams.delete": orgWrite.extend({ teamId: remoteId }).strict(),
  "teams.members": listInput.extend({ organizationId: remoteId, teamId: remoteId }).strict(),
  "teams.addMember": orgWrite.extend({ teamId: remoteId, userId: remoteId }).strict(),
  "teams.removeMember": orgWrite.extend({ teamId: remoteId, userId: remoteId }).strict(),
  "invitations.list": listInput.extend({ organizationId: remoteId }).strict(),
  "invitations.create": orgWrite.extend({ email: z4.email().max(320), role: roleInput, teamId: remoteId.optional() }).strict(),
  "invitations.cancel": orgWrite.extend({ invitationId: remoteId }).strict(),
  "invitations.resend": orgWrite.extend({ invitationId: remoteId }).strict()
};
var pageOf = (item) => z4.object({
  items: z4.array(item).max(100),
  total: z4.number().int().min(0),
  limit: z4.number().int(),
  offset: z4.number().int()
});
var orgDetailSchema = z4.object({
  organization: orgSchema,
  roles: z4.array(z4.string().max(100)).max(200)
});
var ok = z4.object({ success: z4.literal(true) });
var orgOperationOutputs = {
  "organizations.list": pageOf(orgSchema),
  "organizations.get": orgDetailSchema,
  "organizations.create": orgSchema,
  "organizations.update": orgSchema,
  "organizations.delete": ok,
  "members.list": pageOf(memberSchema),
  "members.add": memberSchema,
  "members.role": ok,
  "members.remove": ok,
  "teams.list": pageOf(teamSchema),
  "teams.create": teamSchema,
  "teams.update": ok,
  "teams.delete": ok,
  "teams.members": pageOf(teamMemberSchema),
  "teams.addMember": ok,
  "teams.removeMember": ok,
  "invitations.list": pageOf(invitationSchema),
  "invitations.create": invitationSchema,
  "invitations.cancel": ok,
  "invitations.resend": invitationSchema
};

// packages/protocol/src/index.ts
var roles = ["owner", "admin", "viewer"];
var roleSchema = z5.enum(roles);
var identifier = z5.string().min(1).max(200);
var workspaceIdSchema = z5.uuid();
var pagination = z5.object({
  limit: z5.coerce.number().int().min(1).max(100).default(25),
  offset: z5.coerce.number().int().min(0).max(1e6).default(0)
});
var capabilitiesSchema = z5.object({
  authenticationMethods: z5.boolean().optional(),
  users: z5.object({
    read: z5.boolean(),
    create: z5.boolean(),
    update: z5.boolean(),
    ban: z5.boolean(),
    delete: z5.boolean(),
    setPassword: z5.boolean(),
    createWithPassword: z5.boolean().optional(),
    changeEmail: z5.boolean().optional(),
    impersonate: z5.boolean()
  }),
  sessions: z5.object({ list: z5.boolean(), revoke: z5.boolean(), revokeAll: z5.boolean() }),
  organizations: z5.boolean(),
  teams: z5.boolean(),
  invitations: z5.boolean(),
  twoFactorManagement: z5.boolean(),
  auditEvents: z5.boolean(),
  analytics: z5.boolean()
});
var AppError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
  status;
  code;
};

// packages/protocol/src/signing.ts
import { createHash, createHmac, randomBytes, timingSafeEqual } from "crypto";
var protocolVersion = "1";
var connectorVersion = "0.2.0";
var supportedBetterAuthVersions = ["1.7.3"];
function canonicalJson(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (typeof value === "object" && value !== null && Object.getPrototypeOf(value) === Object.prototype)
    return `{${Object.keys(value).sort().map(
      (key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`
    ).join(",")}}`;
  throw new AppError(400, "invalid_json", "Only JSON values may be signed");
}
var digest = (value) => createHash("sha256").update(value).digest("hex");
function signature(key, method, path, body, timestamp, nonce) {
  return createHmac("sha256", key).update(
    [
      "authplane-management-v1",
      digest(key),
      method.toUpperCase(),
      path,
      timestamp,
      nonce,
      digest(canonicalJson(body))
    ].join("\n")
  ).digest("hex");
}
function verifyRequest(key, method, path, body, headers, now = Date.now()) {
  const timestamp = headers.get("x-authplane-timestamp") ?? "", nonce = headers.get("x-authplane-nonce") ?? "", supplied = headers.get("x-authplane-signature") ?? "";
  const rejected = () => new AppError(
    401,
    "management_unauthorized",
    "The management signature is invalid, expired or belongs to another project"
  );
  if (headers.get("x-authplane-protocol") !== protocolVersion || headers.get("x-authplane-key-id") !== digest(key) || !/^\d{10}$/.test(timestamp) || !/^[-_A-Za-z0-9]{32}$/.test(nonce) || !/^[a-f0-9]{64}$/.test(supplied) || Math.abs(now - Number(timestamp) * 1e3) > 3e4)
    throw rejected();
  const expected = signature(key, method, path, body, timestamp, nonce);
  if (!timingSafeEqual(Buffer.from(supplied, "hex"), Buffer.from(expected, "hex")))
    throw rejected();
  return {
    nonceHash: digest(`${digest(key)}:${nonce}`),
    expiresAt: new Date(Number(timestamp) * 1e3 + 31e3)
  };
}

// packages/better-auth/src/index.ts
import { createAuthEndpoint } from "better-auth/api";
import { z as z10 } from "zod";

// packages/better-auth/src/authentication.ts
import { createHash as createHash2 } from "crypto";
import { getCurrentAdapter as getCurrentAdapter2 } from "@better-auth/core/context";
import { dispatchAuthEndpoint, requestPasswordReset } from "better-auth/api";

// packages/better-auth/src/recovery.ts
import { getCurrentAdapter, runWithTransaction } from "@better-auth/core/context";
function validateRecoveryOptions(options = {}) {
  if ((options.allowPasswordSet || options.allowEmailChange || options.allowTwoFactorReset || options.allowPasskeyRevocation) && typeof options.beforeRecovery !== "function")
    throw new Error(
      "Privileged recovery requires an application-owned beforeRecovery authorization/notification hook"
    );
}
function recoveryCapabilities(ctx, options = {}) {
  const enabled = typeof options.beforeRecovery === "function" && !ctx.options.secondaryStorage && !ctx.options.session?.cookieCache?.enabled;
  return {
    passwordSet: enabled && options.allowPasswordSet === true && ctx.options.emailAndPassword?.enabled === true,
    emailChange: enabled && options.allowEmailChange === true,
    twoFactorReset: enabled && options.allowTwoFactorReset === true && ctx.hasPlugin("two-factor") && (!ctx.options.verification?.storeIdentifier || ctx.options.verification.storeIdentifier === "plain"),
    passkeyRevocation: enabled && options.allowPasskeyRevocation === true && ctx.hasPlugin("passkey")
  };
}
async function authorizeRecovery(ctx, options, action, id, reason) {
  const caps = recoveryCapabilities(ctx, options);
  const allowed = {
    "password.set": caps.passwordSet,
    "email.change": caps.emailChange,
    "twoFactor.reset": caps.twoFactorReset,
    "passkey.revoke": caps.passkeyRevocation
  }[action];
  if (!allowed)
    throw new AppError(
      409,
      "recovery_disabled",
      "This application has not enabled this privileged recovery operation"
    );
  const user2 = await securityUser(ctx, id);
  if (await options.beforeRecovery?.({
    action,
    user: { id, email: user2.email },
    reason: recoveryReason.parse(reason)
  }) !== true)
    throw new AppError(
      403,
      "recovery_rejected",
      "The application's recovery policy rejected this action"
    );
}
async function resetTwoFactor(ctx, options, id, reason) {
  await authorizeRecovery(ctx, options, "twoFactor.reset", id, reason);
  await runWithTransaction(ctx.adapter, async () => {
    const adapter = await getCurrentAdapter(ctx.adapter);
    const grants = await adapter.findMany({
      model: "verification",
      where: [{ field: "value", value: id }],
      select: ["identifier"],
      limit: 1001
    });
    if (grants.length > 1e3)
      throw new AppError(
        409,
        "recovery_limit",
        "Inspect excessive recovery state in the application before retrying"
      );
    for (const grant of grants) {
      if (grant.identifier.startsWith("2fa-") || grant.identifier.startsWith("trust-device-")) {
        await ctx.internalAdapter.deleteVerificationByIdentifier(grant.identifier);
        await ctx.internalAdapter.deleteVerificationByIdentifier(
          `2fa-attempts-${grant.identifier}`
        );
      }
    }
    await adapter.deleteMany({ model: "twoFactor", where: [{ field: "userId", value: id }] });
    const updated = await ctx.internalAdapter.updateUser(id, { twoFactorEnabled: false });
    if (!updated || updated.twoFactorEnabled !== false)
      throw new AppError(409, "recovery_rejected", "The application rejected the factor reset");
    await revokeRecoverySessions(ctx, id);
  });
  return { success: true };
}
async function revokePasskey(ctx, options, id, passkeyId, reason) {
  await authorizeRecovery(ctx, options, "passkey.revoke", id, reason);
  return runWithTransaction(ctx.adapter, async () => {
    const adapter = await getCurrentAdapter(ctx.adapter);
    if (!await ctx.internalAdapter.updateUser(id, { updatedAt: /* @__PURE__ */ new Date() }))
      throw new AppError(409, "recovery_rejected", "The application rejected the recovery lock");
    const security = await userSecurity(ctx, id);
    if (!security.passkeys.some((p) => p.id === passkeyId))
      throw new AppError(
        404,
        "passkey_not_found",
        "Passkey not found for this user in this project"
      );
    const otherLogin = security.password && ctx.options.emailAndPassword?.enabled === true || security.accounts.some((a) => ctx.socialProviders.some((p) => p.id === a.providerId));
    if (security.passkeys.length <= 1 && !otherLogin)
      throw new AppError(
        409,
        "last_login_method",
        "Add and verify another login method in the application before removing this passkey"
      );
    await adapter.deleteMany({
      model: "passkey",
      where: [
        { field: "id", value: passkeyId },
        { field: "userId", value: id }
      ]
    });
    await revokeRecoverySessions(ctx, id);
    return { success: true };
  });
}
async function revokeRecoverySessions(ctx, id) {
  await ctx.internalAdapter.deleteUserSessions(id);
  const adapter = await getCurrentAdapter(ctx.adapter);
  if (await adapter.count({
    model: "session",
    where: [
      { field: "userId", value: id },
      { field: "expiresAt", value: /* @__PURE__ */ new Date(), operator: "gt" }
    ]
  }))
    throw new AppError(
      409,
      "recovery_rejected",
      "The application rejected session revocation; recovery was rolled back"
    );
}

// packages/better-auth/src/authentication.ts
function validateAuthenticationOptions(options = {}) {
  for (const path of [options.passwordResetPath, options.magicLinkCallbackPath]) {
    if (path !== void 0 && (!/^\/(?!\/)[A-Za-z0-9/_-]*$/.test(path) || path.length > 500))
      throw new Error("Authentication callback pages must be fixed absolute application paths");
  }
}
var record = (value) => value && typeof value === "object" ? value : {};
var text = (value, max, fallback = "") => typeof value === "string" ? value.slice(0, max) : fallback;
var iso = (value) => value instanceof Date ? value.toISOString() : value;
function authenticationMethods(ctx, options = {}, recovery = {}) {
  const recoveryCaps = recoveryCapabilities(ctx, recovery);
  const twoFactor = ctx.options.plugins?.find((p) => p.id === "two-factor");
  const magicLink = ctx.options.plugins?.find((p) => p.id === "magic-link");
  const passkey = ctx.options.plugins?.find((p) => p.id === "passkey");
  const factor = record(twoFactor?.options), magic = record(magicLink?.options), keys = record(passkey?.options);
  const google = ctx.socialProviders.find((p) => p.id === "google");
  const googleConfig = record(ctx.options.socialProviders?.google);
  const clientId = googleConfig.clientId;
  const googleConfigured = !!google && (typeof clientId === "string" ? clientId.length > 0 : Array.isArray(clientId) && clientId.some((v) => typeof v === "string" && v.length > 0)) && typeof googleConfig.clientSecret === "string" && googleConfig.clientSecret.length > 0;
  const diagnostics = [];
  if (!google)
    diagnostics.push("Add Google to your application's Better Auth socialProviders configuration.");
  else if (!googleConfigured)
    diagnostics.push(
      "Google credentials are missing or dynamically configured; validate them in the application."
    );
  diagnostics.push(
    "Register this callback URL in Google Cloud. Credential validity and consent-screen settings require a real sign-in test."
  );
  const origins = typeof keys.origin === "string" ? [keys.origin] : Array.isArray(keys.origin) ? keys.origin : [new URL(ctx.baseURL).origin];
  return authenticationMethodsSchema.parse({
    emailPassword: {
      enabled: ctx.options.emailAndPassword?.enabled === true,
      resetEmail: ctx.options.emailAndPassword?.enabled === true && typeof ctx.options.emailAndPassword.sendResetPassword === "function" && !!options.passwordResetPath
    },
    google: {
      enabled: !!google,
      credentialsConfigured: googleConfigured,
      callbackURL: `${ctx.baseURL}/callback/google`,
      diagnostics
    },
    twoFactor: {
      enabled: !!twoFactor,
      totp: !!twoFactor && record(factor.totpOptions).disable !== true,
      otp: !!twoFactor && typeof record(factor.otpOptions).sendOTP === "function",
      allowPasswordless: factor.allowPasswordless === true,
      defaultChallengeMethods: twoFactor ? ["email", "username", "phone-number"] : [],
      customEnforcement: "application-owned",
      reset: recoveryCaps.twoFactorReset
    },
    magicLink: {
      enabled: !!magicLink,
      deliveryConfigured: typeof magic.sendMagicLink === "function",
      expiresIn: typeof magic.expiresIn === "number" && magic.expiresIn > 0 ? magic.expiresIn : 300,
      send: !!magicLink && typeof magic.sendMagicLink === "function" && !!options.magicLinkCallbackPath
    },
    passkeys: {
      enabled: !!passkey,
      rpID: text(keys.rpID, 253, new URL(ctx.baseURL).hostname),
      origins: origins.filter((v) => typeof v === "string").slice(0, 20).map((v) => v.slice(0, 2048)),
      revoke: recoveryCaps.passkeyRevocation
    }
  });
}
async function securityUser(ctx, id) {
  const user2 = await ctx.internalAdapter.findUserById(id);
  if (!user2) throw new AppError(404, "user_not_found", "User not found in this project");
  return user2;
}
async function userSecurity(ctx, id) {
  const adapter = await getCurrentAdapter2(ctx.adapter);
  const user2 = await securityUser(ctx, id);
  const accounts = await adapter.findMany({
    model: "account",
    where: [{ field: "userId", value: id }],
    limit: 101,
    select: ["id", "providerId", "createdAt"]
  });
  const keys = ctx.hasPlugin("passkey") ? await adapter.findMany({
    model: "passkey",
    where: [{ field: "userId", value: id }],
    limit: 101,
    select: ["id", "name", "createdAt", "deviceType", "backedUp"]
  }) : [];
  if (accounts.length > 100 || keys.length > 100)
    throw new AppError(
      409,
      "security_record_limit",
      "More than 100 linked accounts or passkeys; inspect this account in the application"
    );
  const factor = ctx.hasPlugin("two-factor") ? await adapter.findOne({
    model: "twoFactor",
    where: [{ field: "userId", value: id }],
    select: ["verified"]
  }) : null;
  return userSecuritySchema.parse({
    userId: user2.id,
    emailVerified: user2.emailVerified,
    password: !!(await ctx.internalAdapter.findCredentialAccount(id))?.password,
    accounts: accounts.filter((a) => a.providerId !== "credential").map((a) => ({ id: a.id, providerId: text(a.providerId, 200), createdAt: iso(a.createdAt) })),
    twoFactor: {
      enabled: record(user2).twoFactorEnabled === true,
      totpEnrolled: !!factor && factor.verified !== false
    },
    passkeys: keys.map((p) => ({
      id: p.id,
      name: text(p.name, 200, "Unnamed passkey"),
      createdAt: iso(p.createdAt),
      deviceType: text(p.deviceType, 100),
      backedUp: p.backedUp === true
    }))
  });
}
async function manageAuthentication(ctx, operation, input, options = {}, recovery = {}) {
  const parsed = securityOperationInputs[operation].parse(input);
  if (operation === "security.methods") return authenticationMethods(ctx, options, recovery);
  if (!("id" in parsed)) throw new AppError(400, "invalid_request", "A user is required");
  if (operation === "security.user") return userSecurity(ctx, parsed.id);
  if (operation === "security.resetTwoFactor") {
    const data = securityOperationInputs[operation].parse(input);
    return resetTwoFactor(ctx, recovery, data.id, data.reason);
  }
  if (operation === "security.revokePasskey") {
    const data = securityOperationInputs[operation].parse(input);
    return revokePasskey(ctx, recovery, data.id, data.passkeyId, data.reason);
  }
  const methods = authenticationMethods(ctx, options);
  const user2 = await securityUser(ctx, parsed.id);
  if (record(user2).banned === true)
    throw new AppError(409, "user_banned", "Unban this user before initiating account recovery");
  const reset = operation === "security.sendPasswordReset";
  const magic = operation === "security.sendMagicLink";
  if (reset && methods.emailPassword.resetEmail || magic && methods.magicLink.send) {
    if (!user2.emailVerified)
      throw new AppError(
        409,
        "email_not_verified",
        "The application must verify this user's email before administrative login or reset emails can be sent"
      );
    if (magic && record(user2).twoFactorEnabled === true)
      throw new AppError(
        409,
        "factor_bypass_rejected",
        "Administrative magic links are unavailable for users with 2FA; use the application's normal sign-in flow"
      );
    try {
      await ctx.adapter.create({
        model: "authplaneNonce",
        data: {
          nonceHash: `email:${createHash2("sha256").update(`${operation}\0${user2.id}`).digest("hex")}`,
          expiresAt: new Date(Date.now() + 6e4)
        }
      });
    } catch {
      throw new AppError(
        429,
        "email_rate_limited",
        "Wait at least one minute before requesting another email for this user"
      );
    }
    const endpoint = reset ? requestPasswordReset : ctx.getPlugin("magic-link")?.endpoints?.signInMagicLink;
    if (!endpoint)
      throw new AppError(
        409,
        "unsupported_capability",
        "The application's email endpoint is unavailable"
      );
    const body = reset ? { email: user2.email, redirectTo: options.passwordResetPath } : { email: user2.email, callbackURL: options.magicLinkCallbackPath };
    const headers = new Headers({
      "content-type": "application/json",
      origin: new URL(ctx.baseURL).origin
    });
    const request = new Request(`${ctx.baseURL}${endpoint.path}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    });
    try {
      await dispatchAuthEndpoint(endpoint, {
        context: ctx,
        request,
        headers,
        body,
        asResponse: false
      });
    } catch {
      throw new AppError(
        502,
        "email_request_failed",
        "The application rejected the email request; check its delivery diagnostics"
      );
    }
    return { success: true };
  }
  throw new AppError(
    409,
    "unsupported_capability",
    "This security operation is not enabled by the application"
  );
}

// packages/better-auth/src/authorization.ts
import { z as z6 } from "zod";
async function verifyProjectKey(url, key) {
  try {
    const response = await fetch(new URL("/internal/credentials/verify", url), {
      method: "POST",
      headers: { authorization: `Bearer ${key}` },
      redirect: "error",
      signal: AbortSignal.timeout(3e3)
    });
    if (response.status === 401 || response.status === 403) {
      await response.body?.cancel();
      throw new AppError(
        401,
        "project_key_rejected",
        "The control plane rejected this project key"
      );
    }
    if (!response.ok || !/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? "")) {
      await response.body?.cancel();
      throw new Error("Invalid verification response");
    }
    const reader = response.body?.getReader();
    if (!reader) throw new Error("Empty verification response");
    let bytes = 0;
    const chunks = [];
    for (; ; ) {
      const { value, done } = await reader.read();
      if (done) break;
      bytes += value.length;
      if (bytes > 4096) {
        await reader.cancel();
        throw new Error("Oversized verification response");
      }
      chunks.push(value);
    }
    return z6.object({ projectId: z6.uuid(), workspaceId: z6.uuid() }).strict().parse(JSON.parse(Buffer.concat(chunks).toString("utf8")));
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(
      503,
      "control_plane_unavailable",
      "Project authorization cannot be verified right now"
    );
  }
}

// packages/better-auth/src/capabilities.ts
function installedPlugins(ctx) {
  const org = ctx.options.plugins?.find((p) => p.id === "organization");
  return {
    admin: ctx.hasPlugin("admin"),
    organizations: !!org,
    teams: !!org?.schema?.team,
    invitations: typeof org?.options?.sendInvitationEmail === "function",
    twoFactor: ctx.hasPlugin("two-factor")
  };
}
function detectCapabilities(ctx, recovery = {}) {
  const safe = recoveryCapabilities(ctx, recovery);
  return {
    authenticationMethods: true,
    users: {
      read: true,
      create: true,
      update: true,
      ban: ctx.hasPlugin("admin"),
      delete: true,
      createWithPassword: ctx.options.emailAndPassword?.enabled === true,
      changeEmail: safe.emailChange,
      setPassword: safe.passwordSet,
      impersonate: false
    },
    sessions: {
      list: !ctx.options.secondaryStorage,
      revoke: !ctx.options.secondaryStorage,
      revokeAll: true
    },
    organizations: installedPlugins(ctx).organizations,
    teams: installedPlugins(ctx).teams,
    invitations: installedPlugins(ctx).invitations,
    twoFactorManagement: safe.twoFactorReset,
    auditEvents: true,
    analytics: true
  };
}

// packages/better-auth/src/event-delivery.ts
import { createHash as createHash3, randomUUID } from "crypto";
import { getCurrentAdapter as getCurrentAdapter3, runWithTransaction as runWithTransaction2 } from "@better-auth/core/context";
import { z as z7 } from "zod";
var deliverySchema = {
  authplaneOutbox: {
    fields: {
      eventId: { type: "string", required: true, unique: true },
      namespace: { type: "string", required: true, index: true },
      payload: { type: "string", required: true },
      attempts: { type: "number", required: true, defaultValue: 0 },
      nextAttemptAt: { type: "date", required: true, index: true },
      createdAt: { type: "date", required: true }
    }
  },
  authplaneDelivery: {
    fields: {
      namespace: { type: "string", required: true, unique: true },
      queued: { type: "number", required: true, defaultValue: 0 },
      dropped: { type: "number", required: true, defaultValue: 0 },
      boundNamespace: { type: "string", required: false }
    }
  }
};
var RETENTION_MS = 7 * 24 * 60 * 60 * 1e3;
var MAX_ATTEMPTS = 20;
var EventDelivery = class {
  constructor(url, key, options = {}) {
    this.url = url;
    this.key = key;
    this.namespace = createHash3("sha256").update(`${url}
${key}`).digest("hex");
    this.options = z7.object({
      flushIntervalMs: z7.number().int().min(0).max(6e4).default(2e3),
      maxQueuedEvents: z7.number().int().min(1).max(1e5).default(1e4)
    }).parse(options);
  }
  url;
  key;
  ctx;
  timer;
  pending;
  closed = false;
  lastError = null;
  lastSuccessAt = null;
  namespace;
  options;
  init(ctx) {
    this.ctx = ctx;
    if (this.options.flushIntervalMs > 0) {
      this.timer = setInterval(() => void this.flush(), this.options.flushIntervalMs);
      this.timer.unref();
    }
  }
  async ensureNamespace(namespace) {
    const adapter = this.ctx?.adapter;
    if (!adapter) return;
    if (!await adapter.findOne({
      model: "authplaneDelivery",
      where: [{ field: "namespace", value: namespace }]
    })) {
      try {
        await adapter.create({
          model: "authplaneDelivery",
          data: { namespace, queued: 0, dropped: 0 }
        });
      } catch {
      }
    }
  }
  async queueNamespace() {
    const row = await this.ctx?.adapter.findOne({
      model: "authplaneDelivery",
      where: [{ field: "namespace", value: this.namespace }]
    });
    return row?.boundNamespace || this.namespace;
  }
  /** Only called with an identity returned by live project-key verification. */
  async bind(projectId) {
    const ctx = this.ctx;
    if (!ctx) return;
    const destination = createHash3("sha256").update(`${this.url}
project:${projectId}`).digest("hex");
    await this.ensureNamespace(this.namespace);
    await this.ensureNamespace(destination);
    await runWithTransaction2(ctx.adapter, async () => {
      const adapter = await getCurrentAdapter3(ctx.adapter);
      const source = await adapter.incrementOne({
        model: "authplaneDelivery",
        where: [{ field: "namespace", value: this.namespace }],
        increment: { queued: 0 }
      });
      if (!source) throw new Error("Event namespace unavailable");
      if (source.boundNamespace) {
        if (source.boundNamespace !== destination)
          throw new AppError(
            401,
            "project_identity_changed",
            "The project identity changed for an already-bound credential"
          );
        return;
      }
      const target = await adapter.incrementOne({
        model: "authplaneDelivery",
        where: [{ field: "namespace", value: destination }],
        increment: { queued: 0 }
      });
      if (!target) throw new Error("Bound event namespace unavailable");
      const capacity = Math.max(0, this.options.maxQueuedEvents - target.queued);
      const pending = capacity ? await adapter.findMany({
        model: "authplaneOutbox",
        where: [{ field: "namespace", value: this.namespace }],
        sortBy: { field: "createdAt", direction: "asc" },
        limit: capacity
      }) : [];
      const moved = pending.length ? await adapter.updateMany({
        model: "authplaneOutbox",
        where: [
          { field: "namespace", value: this.namespace },
          { field: "eventId", operator: "in", value: pending.map((r) => r.eventId) }
        ],
        update: { namespace: destination }
      }) : 0;
      const dropped = await adapter.deleteMany({
        model: "authplaneOutbox",
        where: [{ field: "namespace", value: this.namespace }]
      });
      await adapter.incrementOne({
        model: "authplaneDelivery",
        where: [{ field: "namespace", value: destination }],
        increment: { queued: moved, dropped: dropped + source.dropped }
      });
      await adapter.update({
        model: "authplaneDelivery",
        where: [{ field: "namespace", value: this.namespace }],
        update: { queued: 0, dropped: 0, boundNamespace: destination }
      });
    });
  }
  async enqueue(event) {
    if (!this.ctx || this.closed) return;
    const ctx = this.ctx;
    try {
      const safe = sourceEventSchema.parse(event);
      await this.ensureNamespace(this.namespace);
      await runWithTransaction2(ctx.adapter, async () => {
        const adapter = await getCurrentAdapter3(ctx.adapter);
        const alias = await adapter.incrementOne({
          model: "authplaneDelivery",
          where: [{ field: "namespace", value: this.namespace }],
          increment: { queued: 0 }
        });
        if (!alias) throw new Error("Event namespace unavailable");
        const namespace = alias.boundNamespace || this.namespace;
        const reserved = await adapter.incrementOne({
          model: "authplaneDelivery",
          where: [
            { field: "namespace", value: namespace },
            { field: "queued", operator: "lt", value: this.options.maxQueuedEvents }
          ],
          increment: { queued: 1 }
        });
        if (!reserved) {
          await adapter.incrementOne({
            model: "authplaneDelivery",
            where: [{ field: "namespace", value: namespace }],
            increment: { dropped: 1 }
          });
          this.lastError = "outbox_full";
          return;
        }
        await adapter.create({
          model: "authplaneOutbox",
          data: {
            eventId: safe.id,
            namespace,
            payload: JSON.stringify(safe),
            attempts: 0,
            nextAttemptAt: /* @__PURE__ */ new Date(),
            createdAt: /* @__PURE__ */ new Date()
          }
        });
      });
    } catch {
      this.lastError = "event_persistence_failed";
    }
  }
  async state() {
    if (!this.ctx)
      return {
        queued: 0,
        dropped: 0,
        failed: 0,
        lastError: this.lastError,
        lastSuccessAt: this.lastSuccessAt
      };
    try {
      const namespace = await this.queueNamespace();
      const [row, failed2] = await Promise.all([
        this.ctx.adapter.findOne({
          model: "authplaneDelivery",
          where: [{ field: "namespace", value: namespace }]
        }),
        this.ctx.adapter.count({
          model: "authplaneOutbox",
          where: [
            { field: "namespace", value: namespace },
            { field: "attempts", operator: "gte", value: MAX_ATTEMPTS }
          ]
        })
      ]);
      return {
        queued: row?.queued ?? 0,
        dropped: row?.dropped ?? 0,
        failed: failed2,
        lastError: this.lastError,
        lastSuccessAt: this.lastSuccessAt
      };
    } catch {
      return {
        queued: 0,
        dropped: 0,
        failed: 0,
        lastError: "event_storage_unavailable",
        lastSuccessAt: this.lastSuccessAt
      };
    }
  }
  async flush() {
    if (this.closed || !this.ctx) return;
    if (this.pending) return this.pending;
    this.pending = this.deliver().catch(() => {
      this.lastError = "event_delivery_failed";
    }).finally(() => {
      this.pending = void 0;
    });
    return this.pending;
  }
  async remove(ids, namespace, dropped = false) {
    const ctx = this.ctx;
    if (!ctx || !ids.length) return;
    await runWithTransaction2(ctx.adapter, async () => {
      const adapter = await getCurrentAdapter3(ctx.adapter);
      const count = await adapter.deleteMany({
        model: "authplaneOutbox",
        where: [
          { field: "namespace", value: namespace },
          { field: "eventId", operator: "in", value: ids }
        ]
      });
      if (count)
        await adapter.incrementOne({
          model: "authplaneDelivery",
          where: [{ field: "namespace", value: namespace }],
          increment: { queued: -count, ...dropped ? { dropped: count } : {} }
        });
    });
  }
  async deliver() {
    const ctx = this.ctx;
    if (!ctx) return;
    const project = await verifyProjectKey(this.url, this.key);
    await this.bind(project.projectId);
    const namespace = await this.queueNamespace();
    const expired = await ctx.adapter.findMany({
      model: "authplaneOutbox",
      where: [
        { field: "namespace", value: namespace },
        { field: "createdAt", operator: "lt", value: new Date(Date.now() - RETENTION_MS) }
      ],
      limit: 100
    });
    await this.remove(
      expired.map((r) => r.eventId),
      namespace,
      true
    );
    const batch = await ctx.adapter.findMany({
      model: "authplaneOutbox",
      where: [
        { field: "namespace", value: namespace },
        { field: "nextAttemptAt", operator: "lte", value: /* @__PURE__ */ new Date() },
        { field: "attempts", operator: "lt", value: MAX_ATTEMPTS }
      ],
      sortBy: { field: "createdAt", direction: "asc" },
      limit: 50
    });
    if (!batch.length) return;
    let acknowledged = [];
    try {
      const response = await fetch(new URL("/internal/events", this.url), {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(3e3),
        headers: { authorization: `Bearer ${this.key}`, "content-type": "application/json" },
        body: JSON.stringify({
          events: batch.map((r) => sourceEventSchema.parse(JSON.parse(r.payload)))
        })
      });
      if (!response.ok || !/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? "")) {
        await response.body?.cancel();
        throw new Error("delivery rejected");
      }
      const reader = response.body?.getReader();
      if (!reader) throw new Error("empty acknowledgement");
      let bytes = 0;
      const chunks = [];
      for (; ; ) {
        const { value, done } = await reader.read();
        if (done) break;
        bytes += value.length;
        if (bytes > 8192) {
          await reader.cancel();
          throw new Error("acknowledgement too large");
        }
        chunks.push(value);
      }
      const ack = eventAckSchema.parse(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      if (ack.acceptedIds.some((id) => !batch.some((row) => row.eventId === id)))
        throw new Error("unexpected acknowledgement");
      acknowledged = [...new Set(ack.acceptedIds)];
      await this.remove(acknowledged, namespace);
      this.lastSuccessAt = (/* @__PURE__ */ new Date()).toISOString();
      this.lastError = acknowledged.length === batch.length ? null : "partial_acknowledgement";
    } catch {
      this.lastError = "event_delivery_failed";
    }
    for (const row of batch.filter((r) => !acknowledged.includes(r.eventId))) {
      const delay = Math.min(6e4, 1e3 * 2 ** Math.min(row.attempts, 6));
      await ctx.adapter.incrementOne({
        model: "authplaneOutbox",
        where: [
          { field: "id", value: row.id },
          { field: "namespace", value: namespace }
        ],
        increment: { attempts: 1 },
        set: {
          nextAttemptAt: new Date(Date.now() + Math.round(delay * (0.8 + Math.random() * 0.4)))
        }
      });
    }
  }
  async retry() {
    const project = await verifyProjectKey(this.url, this.key);
    await this.bind(project.projectId);
    const namespace = await this.queueNamespace();
    await this.ctx?.adapter.updateMany({
      model: "authplaneOutbox",
      where: [{ field: "namespace", value: namespace }],
      update: { attempts: 0, nextAttemptAt: /* @__PURE__ */ new Date() }
    });
    await this.flush();
    return { success: true };
  }
  async close() {
    this.closed = true;
    clearInterval(this.timer);
    await this.pending;
  }
};
function eventEnvelope(type, fields = {}) {
  const id = (value) => typeof value === "string" && value.length > 0 && value.length <= 200 ? value : void 0;
  const ip = z7.union([z7.ipv4(), z7.ipv6()]).safeParse(fields.ip);
  const rawMetadata = fields.metadata && typeof fields.metadata === "object" ? fields.metadata : {};
  const metadata = {};
  for (const key of [
    "endpoint",
    "method",
    "sessionId",
    "teamId",
    "memberId",
    "invitationId"
  ]) {
    const value = id(rawMetadata[key]);
    if (value) metadata[key] = key === "method" ? value.slice(0, 50) : value;
  }
  if (typeof rawMetadata.management === "boolean") metadata.management = rawMetadata.management;
  return sourceEventSchema.parse({
    id: randomUUID(),
    providerEventType: type,
    actorUserId: id(fields.actorUserId),
    targetUserId: id(fields.targetUserId),
    organizationId: id(fields.organizationId),
    occurredAt: fields.occurredAt instanceof Date ? fields.occurredAt.toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    ip: ip.success ? ip.data : void 0,
    userAgent: typeof fields.userAgent === "string" ? fields.userAgent.slice(0, 1024) : void 0,
    metadata
  });
}

// packages/better-auth/src/event-hooks.ts
import {
  queueAfterTransactionHook,
  tryGetCurrentAuthEndpointContext
} from "@better-auth/core/context";
import { APIError, createAuthMiddleware } from "better-auth/api";
var obj = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
function failed(returned, headers) {
  if (returned instanceof APIError && returned.statusCode >= 400) return true;
  if (returned instanceof Response && returned.status >= 400) return true;
  const location = headers?.get("location") ?? (returned instanceof Response ? returned.headers.get("location") : null);
  return location ? new URL(location, "https://local.invalid").searchParams.has("error") : false;
}
function details(context) {
  const body = obj(context?.body), input = obj(body.input);
  const management = context?.path === "/authplane/manage" || !!context?.path?.startsWith("/admin/");
  return {
    actorUserId: input.actorUserId ?? context?.context?.session?.user?.id,
    targetUserId: input.id ?? body.userId,
    metadata: {
      endpoint: context?.path,
      management,
      method: context?.path?.includes("/email") ? "email" : management ? "admin" : "app"
    }
  };
}
function eventHooks(delivery) {
  const emit = async (type, fields) => {
    const event = eventEnvelope(type, fields);
    await queueAfterTransactionHook(() => delivery.enqueue(event), { onError: () => {
    } });
  };
  const databaseHooks = {
    user: {
      create: {
        after: async (user2, context) => {
          await emit("user_created", {
            ...details(context),
            targetUserId: user2.id,
            occurredAt: user2.createdAt
          });
        }
      },
      update: {
        after: async (user2, context) => {
          if (!user2) return;
          const body = obj(context?.body), input = obj(body.input);
          const type = context?.path === "/admin/ban-user" || body.operation === "users.ban" ? "user_banned" : context?.path === "/admin/unban-user" || body.operation === "users.unban" ? "user_unbanned" : "profile_updated";
          await emit(type, { ...details(context), targetUserId: obj(user2).id ?? input.id });
        }
      },
      delete: {
        after: async (user2, context) => {
          await emit("user_deleted", { ...details(context), targetUserId: user2.id });
        }
      }
    },
    session: {
      create: {
        after: async (session, context) => {
          const base = details(context);
          const fields = {
            ...base,
            actorUserId: session.userId,
            targetUserId: session.userId,
            occurredAt: session.createdAt,
            ip: session.ipAddress,
            userAgent: session.userAgent,
            metadata: { ...base.metadata, sessionId: session.id }
          };
          await emit("session_created", fields);
        }
      },
      delete: {
        after: async (session, context) => {
          const base = details(context);
          await emit(context?.path === "/sign-out" ? "user_signed_out" : "session_revoked", {
            ...base,
            targetUserId: session.userId,
            metadata: { ...base.metadata, sessionId: session.id }
          });
        }
      }
    },
    account: {
      create: {
        after: async (account, context) => {
          const base = details(context);
          await emit("account_linked", {
            ...base,
            targetUserId: account.userId,
            metadata: { ...base.metadata, method: account.providerId }
          });
        }
      },
      update: {
        after: async (account, context) => {
          const body = obj(context?.body);
          if (context?.path?.includes("password") || body.operation === "users.setPassword")
            await emit("password_changed", {
              ...details(context),
              targetUserId: obj(account).userId ?? details(context).targetUserId ?? details(context).actorUserId
            });
        }
      }
    }
  };
  const hooks = {
    after: [
      {
        matcher: (ctx) => !!ctx.path && /^(\/(sign-in|sign-up|callback|oauth2\/callback)(\/|$)|\/magic-link\/verify$|\/passkey\/verify-authentication$|\/two-factor\/verify-(totp|otp|backup-code)$)/.test(
          ctx.path
        ),
        handler: createAuthMiddleware(async (ctx) => {
          const returned = ctx.context.returned;
          if (failed(returned, ctx.context.responseHeaders)) return;
          if (obj(returned).twoFactorRedirect === true) {
            await emit("two_factor_challenged", details(ctx));
            return;
          }
          const session = ctx.context.newSession;
          if (!session || ctx.path?.startsWith("/two-factor/") && ctx.context.session) return;
          await emit("user_signed_in", {
            ...details(ctx),
            actorUserId: session.user.id,
            targetUserId: session.user.id,
            metadata: { ...details(ctx).metadata, sessionId: session.session.id }
          });
        })
      },
      {
        matcher: (ctx) => !!ctx.path && (/^\/two-factor\//.test(ctx.path) || /^\/passkey\/(verify-registration|delete-passkey|verify-authentication)$/.test(
          ctx.path
        ) || [
          "/sign-in/magic-link",
          "/magic-link/verify",
          "/request-password-reset",
          "/reset-password"
        ].includes(ctx.path)),
        handler: createAuthMiddleware(async (ctx) => {
          const failure = failed(ctx.context.returned, ctx.context.responseHeaders);
          const names = {
            "/two-factor/enable": "two_factor_enrollment_started",
            "/two-factor/disable": "two_factor_disabled",
            "/two-factor/verify-totp": "two_factor_verified",
            "/two-factor/verify-otp": "two_factor_verified",
            "/two-factor/verify-backup-code": "two_factor_verified",
            "/passkey/verify-registration": "passkey_registered",
            "/passkey/delete-passkey": "passkey_deleted",
            "/passkey/verify-authentication": "passkey_authenticated",
            "/sign-in/magic-link": "magic_link_requested",
            "/magic-link/verify": "magic_link_verified",
            "/request-password-reset": "password_reset_requested",
            "/reset-password": "password_reset_completed"
          };
          const name = names[ctx.path ?? ""];
          if (name)
            await emit(failure ? `${name}_failed` : name, {
              ...details(ctx),
              targetUserId: ctx.context.newSession?.user.id ?? details(ctx).targetUserId ?? details(ctx).actorUserId
            });
        })
      },
      {
        matcher: (ctx) => ctx.path === "/organization/invite-member" && obj(ctx.body).resend === true || ctx.path === "/authplane/manage" && obj(ctx.body).operation === "invitations.resend",
        handler: createAuthMiddleware(async (ctx) => {
          if (ctx.context.returned instanceof APIError || ctx.context.returned instanceof Response && ctx.context.returned.status >= 400)
            return;
          const body = obj(ctx.body), input = ctx.path === "/authplane/manage" ? obj(body.input) : body, base = details(ctx), returned = obj(ctx.context.returned);
          await emit("organization_member_invited", {
            ...base,
            organizationId: input.organizationId ?? returned.organizationId,
            metadata: { ...base.metadata, invitationId: input.invitationId ?? returned.id }
          });
        })
      },
      {
        matcher: (ctx) => !!ctx.path?.startsWith("/sign-in/"),
        handler: createAuthMiddleware(async (ctx) => {
          if (ctx.context.returned instanceof APIError)
            await emit("user_sign_in_failed", { ...details(ctx), targetUserId: void 0 });
        })
      },
      {
        matcher: (ctx) => ctx.path === "/revoke-sessions" || ctx.path === "/admin/revoke-user-sessions" || ctx.path === "/authplane/manage" && obj(ctx.body).operation === "sessions.revokeAll",
        handler: createAuthMiddleware(async (ctx) => {
          if (ctx.context.returned instanceof APIError || ctx.context.returned instanceof Response && ctx.context.returned.status >= 400)
            return;
          const base = details(ctx);
          await emit("all_sessions_revoked", {
            ...base,
            targetUserId: obj(obj(ctx.body).input).userId ?? base.targetUserId ?? base.actorUserId
          });
        })
      }
    ]
  };
  function installOrganizationHooks(ctx) {
    const plugin = ctx.options.plugins?.find((p) => p.id === "organization");
    if (!plugin?.options) return;
    const existing = obj(plugin.options.organizationHooks), next = { ...existing };
    const names = {
      afterCreateOrganization: "organization_created",
      afterUpdateOrganization: "organization_updated",
      afterDeleteOrganization: "organization_deleted",
      afterAddMember: "organization_member_added",
      afterRemoveMember: "organization_member_removed",
      afterUpdateMemberRole: "organization_member_role_updated",
      afterCreateTeam: "organization_team_created",
      afterUpdateTeam: "organization_team_updated",
      afterDeleteTeam: "organization_team_deleted",
      afterAddTeamMember: "organization_team_member_added",
      afterRemoveTeamMember: "organization_team_member_removed",
      afterCreateInvitation: "organization_member_invited",
      afterCancelInvitation: "organization_member_invite_canceled"
    };
    for (const [hook, type] of Object.entries(names)) {
      const original = existing[hook];
      next[hook] = async (data, context) => {
        if (typeof original === "function") await original(data, context);
        const row = obj(data), organization = obj(row.organization), member = obj(row.member ?? row.teamMember), team = obj(row.team), invitation = obj(row.invitation), user2 = obj(row.user);
        const endpoint = tryGetCurrentAuthEndpointContext();
        const base = details(endpoint ?? null);
        await emit(type, {
          ...base,
          targetUserId: member.userId ?? user2.id,
          organizationId: organization.id ?? member.organizationId ?? team.organizationId ?? invitation.organizationId,
          metadata: {
            ...base.metadata,
            memberId: member.id,
            teamId: team.id,
            invitationId: invitation.id
          }
        });
      };
    }
    plugin.options.organizationHooks = next;
  }
  return { databaseHooks, hooks, installOrganizationHooks };
}

// packages/better-auth/src/organizations.ts
import { randomBytes as randomBytes2 } from "crypto";
import { getCurrentAdapter as getCurrentAdapter4, runWithTransaction as runWithTransaction3 } from "@better-auth/core/context";
import { APIError as APIError2 } from "better-auth/api";
import { z as z8 } from "zod";

// packages/better-auth/src/display.ts
function boundDisplayFields(input, limits) {
  const result = { ...input };
  delete result.truncatedFields;
  const shortened = [];
  for (const [field, limit] of Object.entries(limits)) {
    const value = input[field];
    if (typeof value === "string" && value.length > limit) {
      result[field] = `${value.slice(0, limit - 1)}\u2026`;
      shortened.push(field);
    }
  }
  if (shortened.length) result.truncatedFields = shortened;
  return result;
}

// packages/better-auth/src/organizations.ts
var record2 = (value) => z8.record(z8.string(), z8.unknown()).parse(value);
var wire = (value) => JSON.parse(JSON.stringify(value));
async function find(ctx, model, id, organizationId) {
  const where = [
    { field: "id", value: id },
    ...organizationId ? [{ field: "organizationId", value: organizationId }] : []
  ];
  const row = await ctx.adapter.findOne({ model, where });
  if (!row)
    throw new AppError(
      404,
      "organization_resource_not_found",
      "Resource not found in this organization"
    );
  return row;
}
async function decorateMember(ctx, member) {
  const user2 = await ctx.internalAdapter.findUserById(String(member.userId));
  return { ...member, name: user2?.name ?? "Deleted user", email: user2?.email ?? "" };
}
async function native(ctx, endpoint, body, actorUserId) {
  const plugin = ctx.options.plugins?.find((p) => p.id === "organization"), fn = plugin?.endpoints?.[endpoint];
  if (!fn)
    throw new AppError(409, "unsupported_capability", "This organization operation is unavailable");
  const actor = await ctx.internalAdapter.findUserById(actorUserId);
  if (!actor)
    throw new AppError(404, "user_not_found", "The acting application user does not exist");
  const extra = actor;
  if (extra.banned && (!extra.banExpires || new Date(extra.banExpires).getTime() > Date.now()))
    throw new AppError(400, "organization_action_rejected", "The selected acting user is banned");
  const session = {
    user: actor,
    session: {
      id: "authplane-management-context",
      userId: actor.id,
      token: `non-session-${randomBytes2(32).toString("base64url")}`,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date(),
      expiresAt: new Date(Date.now() + 5e3),
      activeOrganizationId: null,
      activeTeamId: null
    }
  };
  try {
    return await runWithTransaction3(ctx.adapter, async () => {
      const current = await getCurrentAdapter4(ctx.adapter);
      const context = { ...ctx, adapter: current, session };
      if (endpoint === "addMember") {
        const check = plugin?.endpoints?.hasPermission;
        if (!check)
          throw new AppError(
            409,
            "unsupported_capability",
            "Member permission checks are unavailable"
          );
        const permission = record2(
          await check({
            body: { organizationId: body.organizationId, permissions: { member: ["create"] } },
            headers: new Headers(),
            context,
            asResponse: false
          })
        );
        const membership = await current.findOne({
          model: "member",
          where: [
            { field: "organizationId", value: String(body.organizationId) },
            { field: "userId", value: actor.id }
          ]
        });
        const creatorRole = String(plugin?.options?.creatorRole ?? "owner");
        if (permission.success !== true || !membership || body.role === creatorRole && !membership.role.split(",").map((r) => r.trim()).includes(creatorRole))
          throw new AppError(
            400,
            "organization_action_rejected",
            "The acting member cannot add users with this role"
          );
      }
      return fn({ body, headers: new Headers(), context, asResponse: false });
    });
  } catch (error) {
    if (error instanceof AppError) throw error;
    if (error instanceof APIError2)
      throw new AppError(
        400,
        "organization_action_rejected",
        "Better Auth rejected the action; check acting member permissions, roles, ownership and application limits"
      );
    throw error;
  }
}
async function manageOrganizations(ctx, operation, raw) {
  const caps = detectCapabilities(ctx);
  if (!caps.organizations || operation.startsWith("teams.") && !caps.teams || operation.startsWith("invitations.") && !caps.invitations)
    throw new AppError(
      409,
      "unsupported_capability",
      "This organization capability is unavailable"
    );
  const input = record2(orgOperationInputs[operation].parse(raw));
  const orgId = typeof input.organizationId === "string" ? input.organizationId : void 0;
  if (orgId) await find(ctx, "organization", orgId);
  if (input.teamId) await find(ctx, "team", String(input.teamId), orgId);
  if (input.memberId) await find(ctx, "member", String(input.memberId), orgId);
  if (input.invitationId) await find(ctx, "invitation", String(input.invitationId), orgId);
  const orgPlugin = ctx.options.plugins?.find((p) => p.id === "organization");
  const roles2 = /* @__PURE__ */ new Set([
    "owner",
    "admin",
    "member",
    ...Object.keys(orgPlugin?.options?.roles ?? {})
  ]);
  if (orgId && orgPlugin?.options?.dynamicAccessControl?.enabled) {
    for (const role of await ctx.adapter.findMany({
      model: "organizationRole",
      where: [{ field: "organizationId", value: orgId }],
      limit: 200
    }))
      roles2.add(String(role.role));
  }
  if (typeof input.role === "string" && !roles2.has(input.role))
    throw new AppError(
      400,
      "organization_action_rejected",
      "Select a role defined by the application"
    );
  const actor = String(input.actorUserId ?? "");
  let result;
  if ([
    "organizations.list",
    "members.list",
    "teams.list",
    "teams.members",
    "invitations.list"
  ].includes(operation)) {
    const model = operation === "organizations.list" ? "organization" : operation === "members.list" ? "member" : operation === "teams.list" ? "team" : operation === "teams.members" ? "teamMember" : "invitation";
    const where = model === "organization" ? input.search ? [
      { field: "name", operator: "contains", value: String(input.search), connector: "OR" },
      { field: "slug", operator: "contains", value: String(input.search), connector: "OR" }
    ] : [] : [
      {
        field: model === "teamMember" ? "teamId" : "organizationId",
        value: String(model === "teamMember" ? input.teamId : orgId)
      }
    ];
    const limit = Number(input.limit), offset = Number(input.offset);
    const [rows, total] = await Promise.all([
      ctx.adapter.findMany({
        model,
        where,
        limit,
        offset,
        sortBy: { field: "id", direction: "asc" }
      }),
      ctx.adapter.count({ model, where })
    ]);
    const items = await Promise.all(
      rows.map(
        async (row) => model === "member" || model === "teamMember" ? decorateMember(ctx, row) : model === "organization" ? { ...row, logo: row.logo ?? null } : model === "team" ? { ...row, updatedAt: row.updatedAt ?? null } : { ...row, role: row.role ?? null, teamId: row.teamId ?? null }
      )
    );
    result = { items, total, limit, offset };
  } else if (operation === "organizations.get") {
    const organization = await find(ctx, "organization", String(orgId));
    result = {
      organization: { ...organization, logo: organization.logo ?? null },
      roles: [...roles2].sort()
    };
  } else if (operation === "organizations.create") {
    const value = record2(
      await native(
        ctx,
        "createOrganization",
        { name: input.name, slug: input.slug, userId: actor, keepCurrentActiveOrganization: true },
        actor
      )
    );
    result = { ...value, logo: value.logo ?? null };
  } else if (operation === "organizations.update") {
    const value = record2(
      await native(ctx, "updateOrganization", { organizationId: orgId, data: input.data }, actor)
    );
    result = { ...value, logo: value.logo ?? null };
  } else if (operation === "organizations.delete") {
    await native(ctx, "deleteOrganization", { organizationId: orgId }, actor);
    result = { success: true };
  } else if (operation === "members.add") {
    const value = record2(
      await native(
        ctx,
        "addMember",
        { organizationId: orgId, userId: input.userId, role: input.role },
        actor
      )
    );
    result = await decorateMember(ctx, value);
  } else if (operation === "members.role") {
    await native(
      ctx,
      "updateMemberRole",
      { organizationId: orgId, memberId: input.memberId, role: input.role },
      actor
    );
    result = { success: true };
  } else if (operation === "members.remove") {
    await native(
      ctx,
      "removeMember",
      { organizationId: orgId, memberIdOrEmail: input.memberId },
      actor
    );
    result = { success: true };
  } else if (operation === "teams.create") {
    const value = record2(
      await native(ctx, "createTeam", { organizationId: orgId, name: input.name }, actor)
    );
    result = { ...value, updatedAt: value.updatedAt ?? null };
  } else if (operation === "teams.update") {
    await native(
      ctx,
      "updateTeam",
      { teamId: input.teamId, data: { name: input.name, organizationId: orgId } },
      actor
    );
    result = { success: true };
  } else if (operation === "teams.delete") {
    await native(ctx, "removeTeam", { organizationId: orgId, teamId: input.teamId }, actor);
    result = { success: true };
  } else if (operation === "teams.addMember" || operation === "teams.removeMember") {
    await native(
      ctx,
      operation === "teams.addMember" ? "addTeamMember" : "removeTeamMember",
      { organizationId: orgId, teamId: input.teamId, userId: input.userId },
      actor
    );
    result = { success: true };
  } else if (operation === "invitations.create" || operation === "invitations.resend") {
    const invitation = operation === "invitations.resend" ? await find(ctx, "invitation", String(input.invitationId), orgId) : input;
    const value = record2(
      await native(
        ctx,
        "createInvitation",
        {
          organizationId: orgId,
          email: invitation.email,
          role: invitation.role ?? "member",
          ...invitation.teamId ? { teamId: invitation.teamId } : {},
          resend: operation === "invitations.resend"
        },
        actor
      )
    );
    result = { ...value, role: value.role ?? null, teamId: value.teamId ?? null };
  } else if (operation === "invitations.cancel") {
    await native(ctx, "cancelInvitation", { invitationId: input.invitationId }, actor);
    result = { success: true };
  } else throw new AppError(409, "unsupported_capability", "Organization operation unavailable");
  const bound = (row) => boundDisplayFields(record2(row), {
    name: 500,
    slug: 500,
    logo: 2048,
    email: 320,
    role: 200,
    status: 100
  });
  const response = record2(wire(result));
  const safe = Array.isArray(response.items) ? { ...response, items: response.items.map(bound) } : response.organization ? { ...response, organization: bound(response.organization) } : bound(response);
  return record2(orgOperationOutputs[operation].parse(safe));
}

// packages/better-auth/src/users-sessions.ts
import { runWithTransaction as runWithTransaction4 } from "@better-auth/core/context";
import { z as z9 } from "zod";
function safeUser(value) {
  const input = boundDisplayFields(z9.record(z9.string(), z9.unknown()).parse(value), {
    name: 500,
    email: 320,
    image: 2048,
    role: 200,
    banReason: 1e3
  });
  const iso2 = (date2) => date2 instanceof Date ? date2.toISOString() : date2;
  return userSchema.parse({
    ...input,
    image: input.image ?? null,
    role: input.role ?? null,
    banned: input.banned ?? false,
    banReason: input.banReason ?? null,
    banExpires: input.banExpires ? iso2(input.banExpires) : null,
    createdAt: iso2(input.createdAt),
    updatedAt: iso2(input.updatedAt)
  });
}
function safeSession(value) {
  const input = boundDisplayFields(z9.record(z9.string(), z9.unknown()).parse(value), {
    ipAddress: 200,
    userAgent: 1024
  });
  const iso2 = (date2) => date2 instanceof Date ? date2.toISOString() : date2;
  return sessionSchema.parse({
    ...input,
    ipAddress: input.ipAddress ?? null,
    userAgent: input.userAgent ?? null,
    createdAt: iso2(input.createdAt),
    updatedAt: iso2(input.updatedAt),
    expiresAt: iso2(input.expiresAt)
  });
}
async function user(ctx, id) {
  const found = await ctx.internalAdapter.findUserById(id);
  if (!found) throw new AppError(404, "user_not_found", "User not found in this project");
  return found;
}
async function manageUsersSessions(ctx, operation, input, recovery = {}) {
  const caps = detectCapabilities(ctx, recovery);
  const requireCapability = (enabled) => {
    if (!enabled)
      throw new AppError(
        409,
        "unsupported_capability",
        "This operation is unavailable in this Better Auth configuration"
      );
  };
  if (operation === "users.list") {
    requireCapability(caps.users.read);
    const query = usersListInput.parse(input);
    const where = query.search ? [
      { field: "email", operator: "contains", value: query.search, connector: "OR" },
      { field: "name", operator: "contains", value: query.search, connector: "OR" }
    ] : [];
    const [items, total] = await Promise.all([
      ctx.internalAdapter.listUsers(
        query.limit,
        query.offset,
        { field: "id", direction: "asc" },
        where
      ),
      ctx.internalAdapter.countTotalUsers(where)
    ]);
    return { items: items.map(safeUser), total, limit: query.limit, offset: query.offset };
  }
  if (operation === "users.create") {
    requireCapability(caps.users.create);
    const data = userCreateInput.parse(input);
    if (await ctx.internalAdapter.findUserByEmail(data.email))
      throw new AppError(400, "email_exists", "An account with this email already exists");
    let hash;
    if (data.password !== void 0) {
      requireCapability(ctx.options.emailAndPassword?.enabled === true);
      if (data.password.length < ctx.password.config.minPasswordLength || data.password.length > ctx.password.config.maxPasswordLength)
        throw new AppError(
          400,
          "password_policy",
          "The password does not meet the application's length policy"
        );
      hash = await ctx.password.hash(data.password);
    }
    return runWithTransaction4(ctx.adapter, async () => {
      const created = await ctx.internalAdapter.createUser(
        { name: data.name, email: data.email, emailVerified: false },
        { method: "admin" }
      );
      if (!created) throw new AppError(400, "user_rejected", "The application rejected this user");
      if (hash) {
        const account = await ctx.internalAdapter.linkAccount({
          userId: created.id,
          providerId: "credential",
          accountId: created.id,
          password: hash
        });
        if (!account)
          throw new AppError(400, "user_rejected", "The application rejected credential creation");
      }
      return safeUser(created);
    });
  }
  if (operation === "users.get") {
    requireCapability(caps.users.read);
    const { id } = z9.object({ id: remoteId }).strict().parse(input);
    return safeUser(await user(ctx, id));
  }
  if (operation === "users.update") {
    requireCapability(caps.users.update);
    const { id, data, reason } = z9.object({ id: remoteId, data: userUpdateInput, reason: recoveryReason.optional() }).strict().parse(input);
    const existing = await user(ctx, id);
    const emailChanged = data.email !== void 0 && data.email.toLowerCase() !== existing.email.toLowerCase();
    const { email, ...profile } = data;
    if (emailChanged) await authorizeRecovery(ctx, recovery, "email.change", id, reason);
    return runWithTransaction4(ctx.adapter, async () => {
      const updated = await ctx.internalAdapter.updateUser(id, {
        ...profile,
        ...emailChanged ? { email, emailVerified: false } : {},
        updatedAt: /* @__PURE__ */ new Date()
      });
      if (emailChanged) {
        if (!updated || updated.emailVerified)
          throw new AppError(
            409,
            "email_change_rejected",
            "The application must leave a changed email unverified"
          );
        await revokeRecoverySessions(ctx, id);
      }
      return safeUser(updated);
    });
  }
  if (operation === "users.ban" || operation === "users.unban") {
    requireCapability(caps.users.ban);
    const { id, reason } = z9.object({ id: remoteId, reason: z9.string().max(1e3).optional() }).strict().parse(input);
    await user(ctx, id);
    return runWithTransaction4(ctx.adapter, async () => {
      const updated = await ctx.internalAdapter.updateUser(id, {
        banned: operation === "users.ban",
        banReason: operation === "users.ban" ? reason ?? "Managed in AuthYard" : null,
        banExpires: null,
        updatedAt: /* @__PURE__ */ new Date()
      });
      if (operation === "users.ban") await ctx.internalAdapter.deleteUserSessions(id);
      return safeUser(updated);
    });
  }
  if (operation === "users.delete") {
    requireCapability(caps.users.delete);
    const { id } = z9.object({ id: remoteId }).strict().parse(input);
    await user(ctx, id);
    await runWithTransaction4(ctx.adapter, async () => {
      await ctx.internalAdapter.deleteUserSessions(id);
      await ctx.internalAdapter.deleteUser(id);
    });
    return { success: true };
  }
  if (operation === "users.setPassword") {
    requireCapability(caps.users.setPassword);
    const { id, password, reason } = z9.object({ id: remoteId, password: z9.string().min(8).max(128), reason: recoveryReason }).strict().parse(input);
    await authorizeRecovery(ctx, recovery, "password.set", id, reason);
    if (password.length < ctx.password.config.minPasswordLength || password.length > ctx.password.config.maxPasswordLength)
      throw new AppError(
        400,
        "password_policy",
        "The password does not meet the application's length policy"
      );
    const hash = await ctx.password.hash(password);
    await runWithTransaction4(ctx.adapter, async () => {
      if (await ctx.internalAdapter.findCredentialAccount(id))
        await ctx.internalAdapter.updatePassword(id, hash);
      else
        await ctx.internalAdapter.createAccount({
          userId: id,
          providerId: "credential",
          accountId: id,
          password: hash
        });
      if ((await ctx.internalAdapter.findCredentialAccount(id))?.password !== hash)
        throw new AppError(400, "user_rejected", "The application rejected the password change");
      await revokeRecoverySessions(ctx, id);
    });
    return { success: true };
  }
  if (operation === "sessions.list") {
    requireCapability(caps.sessions.list);
    const query = sessionsListInput.parse(input);
    const where = [
      { field: "expiresAt", operator: "gt", value: /* @__PURE__ */ new Date() },
      ...query.userId ? [{ field: "userId", value: query.userId }] : []
    ];
    const [items, total] = await Promise.all([
      ctx.adapter.findMany({
        model: "session",
        where,
        limit: query.limit,
        offset: query.offset,
        sortBy: { field: "id", direction: "asc" },
        select: ["id", "userId", "createdAt", "updatedAt", "expiresAt", "ipAddress", "userAgent"]
      }),
      ctx.adapter.count({ model: "session", where })
    ]);
    return { items: items.map(safeSession), total, limit: query.limit, offset: query.offset };
  }
  if (operation === "sessions.revoke") {
    requireCapability(caps.sessions.revoke);
    const { id } = z9.object({ id: remoteId }).strict().parse(input);
    const session = await ctx.adapter.findOne({
      model: "session",
      where: [{ field: "id", value: id }],
      select: ["token"]
    });
    if (!session) throw new AppError(404, "session_not_found", "Session not found in this project");
    await ctx.internalAdapter.deleteSession(session.token);
    return { success: true };
  }
  if (operation === "sessions.revokeAll") {
    requireCapability(caps.sessions.revokeAll);
    const { userId } = z9.object({ userId: remoteId }).strict().parse(input);
    await user(ctx, userId);
    await ctx.internalAdapter.deleteUserSessions(userId);
    return { success: true };
  }
  throw new AppError(
    409,
    "unsupported_capability",
    "This operation is not available in the connector"
  );
}

// packages/better-auth/src/index.ts
function controlPlane(options) {
  validateAuthenticationOptions(options.authentication);
  validateRecoveryOptions(options.recovery);
  const url = new URL(options.url);
  if (url.username || url.password || url.pathname !== "/" || url.search || url.hash || !(url.protocol === "https:" || url.protocol === "http:" && options.allowInsecureHttp))
    throw new Error(
      "Control-plane URL must be an HTTPS origin; local development requires allowInsecureHttp"
    );
  if (!/^ap_v1_[A-Za-z0-9_-]{43}$/.test(options.projectKey))
    throw new Error("Configure a valid AuthYard project key");
  const delivery = new EventDelivery(url.origin, options.projectKey, options.events);
  const events = eventHooks(delivery);
  const plugin = {
    id: "authplane",
    version: connectorVersion,
    init(ctx) {
      const plugins = ctx.options.plugins ?? [];
      const index = plugins.findIndex((p) => p.id === "authplane");
      if (plugins.slice(index + 1).some((p) => p.hooks?.after?.length))
        throw new Error(
          "Place the AuthYard connector after plugins with authentication hooks so events observe the final sign-in result"
        );
      delivery.init(ctx);
      events.installOrganizationHooks(ctx);
      return { options: { databaseHooks: events.databaseHooks } };
    },
    hooks: events.hooks,
    schema: {
      ...deliverySchema,
      authplaneNonce: {
        fields: {
          nonceHash: { type: "string", required: true, unique: true },
          expiresAt: { type: "date", required: true, index: true }
        }
      }
    },
    endpoints: {
      authplaneManage: createAuthEndpoint(
        "/authplane/manage",
        { method: "POST", body: z10.unknown(), requireHeaders: true },
        async (ctx) => {
          try {
            if (!ctx.request)
              throw new AppError(
                401,
                "management_unauthorized",
                "A signed HTTP request is required"
              );
            if (Buffer.byteLength(canonicalJson(ctx.body)) > 1048576)
              throw new AppError(413, "body_too_large", "Management request exceeds 1 MiB");
            const requestUrl = new URL(ctx.request.url);
            const nonce = verifyRequest(
              options.projectKey,
              ctx.request.method,
              requestUrl.pathname + requestUrl.search,
              ctx.body,
              ctx.request.headers
            );
            const project = await verifyProjectKey(url.origin, options.projectKey);
            if (!supportedBetterAuthVersions.includes(ctx.context.version))
              throw new AppError(
                409,
                "incompatible_version",
                "This Better Auth version has not been tested with the connector"
              );
            if (!ctx.context.options.database)
              throw new AppError(
                409,
                "incompatible_storage",
                "The connector requires a persistent Better Auth database"
              );
            await ctx.context.adapter.deleteMany({
              model: "authplaneNonce",
              where: [{ field: "expiresAt", operator: "lt", value: /* @__PURE__ */ new Date() }]
            });
            try {
              await ctx.context.adapter.create({ model: "authplaneNonce", data: nonce });
            } catch {
              throw new AppError(
                401,
                "management_replayed",
                "This management request was already used or replay protection is unavailable"
              );
            }
            await delivery.bind(project.projectId);
            const input = z10.object({
              operation: z10.string().min(1).max(100),
              input: z10.record(z10.string(), z10.unknown()).default({})
            }).strict().parse(ctx.body);
            if (input.operation === "events.retry") return ctx.json(await delivery.retry());
            if (Object.hasOwn(securityOperationInputs, input.operation))
              return ctx.json(
                await manageAuthentication(
                  ctx.context,
                  input.operation,
                  input.input,
                  options.authentication,
                  options.recovery
                )
              );
            if (Object.hasOwn(orgOperationInputs, input.operation))
              return ctx.json(
                await manageOrganizations(
                  ctx.context,
                  input.operation,
                  input.input
                )
              );
            if (input.operation !== "health")
              return ctx.json(
                await manageUsersSessions(
                  ctx.context,
                  input.operation,
                  input.input,
                  options.recovery
                )
              );
            return ctx.json({
              protocolVersion,
              connectorVersion,
              betterAuthVersion: ctx.context.version,
              projectId: project.projectId,
              applicationOrigin: new URL(ctx.context.baseURL).origin,
              basePath: new URL(ctx.context.baseURL).pathname,
              capabilities: detectCapabilities(ctx.context, options.recovery),
              plugins: installedPlugins(ctx.context),
              delivery: await delivery.state()
            });
          } catch (error) {
            const safe = error instanceof AppError ? error : error instanceof z10.ZodError ? new AppError(400, "invalid_request", "Invalid management request fields") : new AppError(
              500,
              "management_failed",
              "The management request could not be completed"
            );
            return new Response(
              JSON.stringify({ error: { code: safe.code, message: safe.message } }),
              {
                status: safe.status,
                headers: { "content-type": "application/json", "cache-control": "no-store" }
              }
            );
          }
        }
      )
    }
  };
  return Object.assign(plugin, {
    flushEvents: () => delivery.flush(),
    retryEvents: () => delivery.retry(),
    eventDeliveryState: () => delivery.state(),
    close: () => delivery.close()
  });
}
export {
  controlPlane
};
