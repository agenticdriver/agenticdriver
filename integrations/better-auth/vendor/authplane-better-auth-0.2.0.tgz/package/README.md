# Owned Better Auth connector protocol 1

The current connector is **0.2.0** for Better Auth **1.7.3**, protocol **1**. Connector 0.1.0 retains base operational support, with password/email recovery disabled by the new control plane. See the [tested matrix](better-auth-compatibility.md). The dash compatibility lab remains a separate investigation. Production management uses `@authplane/better-auth`; no `@better-auth/infra` service is emulated by this connector.

Build the distributable from the AuthYard checkout with `pnpm install --frozen-lockfile` and `pnpm connector:pack`. In the customer's application, install the resulting tarball:

```sh
pnpm add /absolute/path/to/authyard/.artifacts/packages/authplane-better-auth-0.2.0.tgz better-auth@1.7.3
```

The tarball contains JavaScript and TypeScript declarations, bundles the internal protocol and preserves the exact Better Auth peer requirement. It needs no workspace links or proprietary account. `pnpm test:package` installs it into an isolated application outside the checkout and checks its types, actual Better Auth migrations, signup, signed discovery/management and acknowledged events. It is not published to npm by this repository's build or CI.

```ts
import { controlPlane } from "@authplane/better-auth";

// Add to your existing Better Auth plugins. Keep your current database and auth configuration.
controlPlane({
  url: process.env.AUTH_CONTROL_PLANE_URL!,
  projectKey: process.env.AUTH_CONTROL_PLANE_PROJECT_KEY!,
  // allowInsecureHttp: true, // explicit local HTTP development only
});
```

Apply Better Auth's generated migration after adding the plugin. The `authplaneNonce` table contains only replay hashes and expiration times. It needs a unique constraint on `nonceHash` and an index on `expiresAt`. Customer auth records remain in the application's database. The plugin requires Node.js 24+ and persistent database storage; secondary-storage-only deployments are unsupported. Install the built tarball; the package is not published to npm.

Event delivery also creates `authplaneOutbox` and `authplaneDelivery`; see [event delivery](event-delivery.md) for retry, acknowledgement, shutdown, limits and delivery guarantees.

The fixed endpoint is `POST <auth-base-path>/authplane/manage`. JSON contains `{ "operation": "health", "input": {} }` for discovery. There is no generic database executor. Operation handlers enable capabilities only when implemented and supported by the installed Better Auth configuration.

Every request has these headers:

| Header | Value |
| --- | --- |
| `x-authplane-protocol` | `1` |
| `x-authplane-key-id` | lowercase SHA-256 hex digest of the full project key |
| `x-authplane-timestamp` | Unix seconds, exactly ten decimal digits |
| `x-authplane-nonce` | 24 random bytes encoded as 32 base64url characters |
| `x-authplane-signature` | lowercase HMAC-SHA-256 hex, using the full project key |

The HMAC message is the following seven UTF-8 values joined with a newline, without a trailing newline: `authplane-management-v1`, key digest, uppercase HTTP method, exact URL pathname plus query, timestamp, nonce, and SHA-256 hex of the canonical JSON body. Canonical JSON sorts object keys recursively, preserves array order and accepts only JSON primitives/objects/arrays. Project keys never appear in the body. A modified operation, target, payload, path/query, method, key or timestamp invalidates authorization.

The application checks the signature and permits at most 30 seconds of clock difference. It then calls the configured control plane's `POST /internal/credentials/verify` with `Authorization: Bearer <project-key>`. The response must be JSON `{projectId, workspaceId}` with UUID identifiers. It has a three-second deadline, a 4096-byte bound, no redirects and **no success cache**. Revoked keys fail with 401; verification outages fail closed with 503 for management. Ordinary application signup/signin never use this callback.

After successful authorization the connector atomically inserts `SHA-256(key-digest + ':' + nonce)` into `authplaneNonce`. The unique constraint admits one concurrent request. Expiration is the signed timestamp plus 31 seconds; expired rows are cleaned before subsequent authorized requests. A replay after expiration is still rejected by timestamp validation. This works across process restarts and instances sharing the same database. Safe error codes and messages are returned as `{error:{code,message}}`; remote exception payloads are never forwarded. The control plane does not automatically retry management calls.

`health` reports protocol/connector/Better Auth versions, verified project identifier, available management capabilities, installed plugin flags and bounded event delivery counters. Organization/team/invitation features are distinguished; invitation delivery requires the customer's `sendInvitationEmail` callback. Discovery contains no auth database records or credentials. Unsupported versions and operations return 409.

Tests use the actual published Better Auth package, migrated SQLite/PostgreSQL databases, real loopback HTTP, concurrent replay, request tampering, verifier outages and ordinary auth during outages. The use of Better Auth's [plugin endpoints, schema and adapter context](https://better-auth.com/docs/concepts/plugins) is covered by the contract suite. No cloud service is required.

## Users and sessions

The internal `AuthProjectAdapter` is implemented by `BetterAuthAdapter`. The console/API use its user/session methods. Provider-specific operation names and signed requests stay inside the adapter/connector. Connect verifies the returned project ID, application origin, auth base path and supported versions before persisting the verified origin and capabilities. Application changes clear verification. Operational HTTP endpoints are beneath `/v1/workspaces/:workspaceId/projects/:projectId`; each checks membership, project scope and the stored verified origin and records an administrative audit event.

| Operation | Capability / behavior |
| --- | --- |
| `users.list`, `users.get` | Remote safe user DTOs; email/name search; limit 1–100 and offset; ID ordering |
| `users.create` | Profile plus optional password; Better Auth hooks and transactional account creation; email starts unverified |
| `users.update` | Name/image; email replacement requires explicit recovery policy and a reason, clears verification and revokes sessions |
| `users.ban`, `users.unban` | Requires admin plugin; ban ends current sessions and prevents native sign-in; indefinite ban with optional reason |
| `users.delete` | Better Auth removes user/accounts/sessions; no auth records copied into AuthYard |
| `users.setPassword` | Disabled by default; explicit recovery policy, reason, native hashing/length policy and transactional session revocation |
| `sessions.list` | Active project/user sessions; paginated; unavailable with secondary session storage |
| `sessions.revoke` | Accepts a session ID, resolves its token only inside the customer app, calls native revocation; unavailable with secondary storage |
| `sessions.revokeAll` | Native per-user revocation, including the app's secondary-storage handling |

Customer `databaseHooks` still run. Credential creation rolls back the user if account creation is rejected. These internal Better Auth adapter/transaction calls are pinned and covered by real-package integration tests; they are not a generic database API. User/session output allowlists exclude account objects, password hashes, private plugin fields and bearer tokens. Passwords are carried only in explicitly requested write bodies over the secured transport, never in audit payloads. Impersonation and 2FA secret management are unavailable. Administrative mutations are not retried; transport failures after a write may have an uncertain outcome, recorded as `uncertain` in the control-plane audit.

The tested management matrix is Better Auth 1.7.3 + owned connector 0.1.0, with native SQLite and PostgreSQL customer databases and separate PostgreSQL control-plane storage. Tests cover two independent projects, missing admin/organization plugins, email/password disabled, and capability suppression with secondary session storage. The secondary-storage test establishes capability detection, not a general secondary-storage implementation guarantee.

Connector 0.2.0 adds `security.methods`, `security.user`, `security.sendPasswordReset`, `security.sendMagicLink`, `security.resetTwoFactor` and `security.revokePasskey`. Inputs and safe outputs are defined in `packages/protocol/src/authentication.ts`. Writes require a user ID and a reason; passkey revocation also requires its native record ID. Email endpoints never return a token or link. Privileged recovery requires an application-owned opt-in/authorization hook. See [authentication methods](authentication-methods.md) and [the recovery security boundary](security.md#customer-account-recovery-policy).

Native Better Auth can store display values longer than this management interface permits. The connector bounds names/slugs to 500 characters, email to 320, image/logo URLs to 2048, roles/IP addresses to 200, ban reasons to 1000, session user agents to 1024, and invitation status to 100. Shortened values end in an ellipsis and their field names appear in optional `truncatedFields`. This metadata is computed by the connector, never accepted from a custom customer field. Canonical records and immutable IDs are never truncated. The console marks shortened values and sends only edited fields; replacing a long value requires entering its replacement. This prevents native long signup names or user agents from making an entire management page unavailable. Real native signup, session, organization/team and browser regression tests cover this boundary.

## Organizations, members, teams and invitations

When the organization plugin is installed, organization lists/details and membership are queried from the application with pagination and safe DTOs. Teams require the plugin's team schema. Invitation management requires its configured `sendInvitationEmail` callback. Missing capabilities return `unsupported_capability` and are hidden by the console. Static/custom roles and up to 200 dynamic roles are discovered from the installed plugin; this version assigns one role per mutation.

Organization writes require an explicit `actorUserId`: a real application user whose membership and permissions Better Auth will check. Creation uses this user as the new organization owner. The connector provides an ephemeral execution context to the installed plugin's native endpoint handlers, without creating a database session, issuing a token, setting a browser cookie, or exporting credentials. Banned acting users are rejected. The control-plane administrator and operation target are recorded separately in AuthYard's administrative audit.

| Operation group | Supported operations |
| --- | --- |
| `organizations` | list, get, create, update, delete |
| `members` | list, add, role, remove |
| `teams` | list, create, update, delete, members, addMember, removeMember |
| `invitations` | list, create, cancel, resend |

The control plane exposes fixed REST routes under a project's `/organizations` path. The adapter maps these to a finite typed operation set. The connector verifies every organization/member/team/invitation reference belongs to the requested organization before calling Better Auth. Native role checks, last-owner restrictions, hooks, creation/membership/team limits, deletion configuration and the customer's invitation callback remain effective. The privileged server-only `addMember` handler is additionally gated by the installed plugin's `hasPermission` endpoint and creator-role restrictions. Native transactions supply the current transaction adapter to avoid opening a second connection from nested handlers.

Contract tests cover every operation, real invitation callbacks and resend/cancel state, native hooks, last-owner removal/demotion, forbidden acting users, invalid roles, cross-organization/project references and disabled plugins. They also assert that organization management creates zero live application sessions. Ordinary invitation acceptance stays in the customer's application.

`events.retry` is an authenticated management operation that resets attempts for the verified project queue and attempts a delivery. The API exposes it as `POST .../events/retry` for owners/admins and audits it. The same operation is available as the server-side `connector.retryEvents()` method. Apply the connector migration including `authplaneDelivery.boundNamespace` before upgrading.
