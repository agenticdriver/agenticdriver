import * as better_auth from 'better-auth';
import { z } from 'zod';

type RecoveryAction = "password.set" | "email.change" | "twoFactor.reset" | "passkey.revoke";
type RecoveryOptions = {
    allowPasswordSet?: boolean;
    allowEmailChange?: boolean;
    allowTwoFactorReset?: boolean;
    allowPasskeyRevocation?: boolean;
    /** App-owned identity verification/notification policy. Throw or return false to reject. */
    beforeRecovery?: (request: {
        action: RecoveryAction;
        user: {
            id: string;
            email: string;
        };
        reason: string;
    }) => Promise<boolean>;
};

type AuthenticationOptions = {
    /** App-owned pages. Paths are fixed at startup, never supplied by an administrator. */
    passwordResetPath?: string;
    magicLinkCallbackPath?: string;
};

type DeliveryOptions = {
    flushIntervalMs?: number;
    maxQueuedEvents?: number;
};

type ControlPlaneOptions = {
    url: string;
    projectKey: string;
    allowInsecureHttp?: boolean;
    events?: DeliveryOptions;
    authentication?: AuthenticationOptions;
    recovery?: RecoveryOptions;
};
declare function controlPlane(options: ControlPlaneOptions): {
    id: "authplane";
    version: string;
    init(ctx: better_auth.AuthContext): {
        options: {
            databaseHooks: {
                user: {
                    create: {
                        after: (user: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            email: string;
                            emailVerified: boolean;
                            name: string;
                            image?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                    update: {
                        after: (user: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            email: string;
                            emailVerified: boolean;
                            name: string;
                            image?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                    delete: {
                        after: (user: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            email: string;
                            emailVerified: boolean;
                            name: string;
                            image?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                };
                session: {
                    create: {
                        after: (session: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            userId: string;
                            expiresAt: Date;
                            token: string;
                            ipAddress?: string | null | undefined;
                            userAgent?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                    delete: {
                        after: (session: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            userId: string;
                            expiresAt: Date;
                            token: string;
                            ipAddress?: string | null | undefined;
                            userAgent?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                };
                account: {
                    create: {
                        after: (account: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            providerId: string;
                            accountId: string;
                            userId: string;
                            accessToken?: string | null | undefined;
                            refreshToken?: string | null | undefined;
                            idToken?: string | null | undefined;
                            accessTokenExpiresAt?: Date | null | undefined;
                            refreshTokenExpiresAt?: Date | null | undefined;
                            scope?: string | null | undefined;
                            password?: string | null | undefined;
                        }, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                    update: {
                        after: (account: {
                            id: string;
                            createdAt: Date;
                            updatedAt: Date;
                            providerId: string;
                            accountId: string;
                            userId: string;
                            accessToken?: string | null | undefined;
                            refreshToken?: string | null | undefined;
                            idToken?: string | null | undefined;
                            accessTokenExpiresAt?: Date | null | undefined;
                            refreshTokenExpiresAt?: Date | null | undefined;
                            scope?: string | null | undefined;
                            password?: string | null | undefined;
                        } & Record<string, unknown>, context: better_auth.GenericEndpointContext | null) => Promise<void>;
                    };
                };
            };
        };
    };
    hooks: {
        after: {
            matcher: (ctx: better_auth.HookEndpointContext) => boolean;
            handler: better_auth.Middleware<better_auth.MiddlewareOptions, (inputContext: better_auth.MiddlewareInputContext<better_auth.MiddlewareOptions>) => Promise<void>>;
        }[];
    };
    schema: {
        authplaneNonce: {
            fields: {
                nonceHash: {
                    type: "string";
                    required: true;
                    unique: true;
                };
                expiresAt: {
                    type: "date";
                    required: true;
                    index: true;
                };
            };
        };
        authplaneOutbox: {
            fields: {
                eventId: {
                    type: "string";
                    required: true;
                    unique: true;
                };
                namespace: {
                    type: "string";
                    required: true;
                    index: true;
                };
                payload: {
                    type: "string";
                    required: true;
                };
                attempts: {
                    type: "number";
                    required: true;
                    defaultValue: number;
                };
                nextAttemptAt: {
                    type: "date";
                    required: true;
                    index: true;
                };
                createdAt: {
                    type: "date";
                    required: true;
                };
            };
        };
        authplaneDelivery: {
            fields: {
                namespace: {
                    type: "string";
                    required: true;
                    unique: true;
                };
                queued: {
                    type: "number";
                    required: true;
                    defaultValue: number;
                };
                dropped: {
                    type: "number";
                    required: true;
                    defaultValue: number;
                };
                boundNamespace: {
                    type: "string";
                    required: false;
                };
            };
        };
    };
    endpoints: {
        authplaneManage: better_auth.StrictEndpoint<"/authplane/manage", {
            method: "POST";
            body: z.ZodUnknown;
            requireHeaders: true;
        }, Record<string, unknown> | Response | {
            emailPassword: {
                enabled: boolean;
                resetEmail: boolean;
            };
            google: {
                enabled: boolean;
                credentialsConfigured: boolean;
                callbackURL: string;
                diagnostics: string[];
            };
            twoFactor: {
                enabled: boolean;
                totp: boolean;
                otp: boolean;
                allowPasswordless: boolean;
                defaultChallengeMethods: ("email" | "username" | "phone-number")[];
                customEnforcement: "application-owned";
                reset: boolean;
            };
            magicLink: {
                enabled: boolean;
                deliveryConfigured: boolean;
                expiresIn: number;
                send: boolean;
            };
            passkeys: {
                enabled: boolean;
                rpID: string;
                origins: string[];
                revoke: boolean;
            };
        } | {
            userId: string;
            emailVerified: boolean;
            password: boolean;
            accounts: {
                id: string;
                providerId: string;
                createdAt: string;
            }[];
            twoFactor: {
                enabled: boolean;
                totpEnrolled: boolean;
            };
            passkeys: {
                id: string;
                name: string;
                createdAt: string;
                deviceType: string;
                backedUp: boolean;
            }[];
        } | {
            success: boolean;
        } | {
            protocolVersion: string;
            connectorVersion: string;
            betterAuthVersion: string;
            projectId: string;
            applicationOrigin: string;
            basePath: string;
            capabilities: {
                users: {
                    read: boolean;
                    create: boolean;
                    update: boolean;
                    ban: boolean;
                    delete: boolean;
                    setPassword: boolean;
                    impersonate: boolean;
                    createWithPassword?: boolean | undefined;
                    changeEmail?: boolean | undefined;
                };
                sessions: {
                    list: boolean;
                    revoke: boolean;
                    revokeAll: boolean;
                };
                organizations: boolean;
                teams: boolean;
                invitations: boolean;
                twoFactorManagement: boolean;
                auditEvents: boolean;
                analytics: boolean;
                authenticationMethods?: boolean | undefined;
            };
            plugins: {
                admin: boolean;
                organizations: boolean;
                teams: boolean;
                invitations: boolean;
                twoFactor: boolean;
            };
            delivery: {
                queued: number;
                dropped: number;
                failed: number;
                lastError: string | null;
                lastSuccessAt: string | null;
            };
        }>;
    };
} & {
    flushEvents: () => Promise<void>;
    retryEvents: () => Promise<{
        success: true;
    }>;
    eventDeliveryState: () => Promise<{
        queued: number;
        dropped: number;
        failed: number;
        lastError: string | null;
        lastSuccessAt: string | null;
    }>;
    close: () => Promise<void>;
};

export { type ControlPlaneOptions, controlPlane };
